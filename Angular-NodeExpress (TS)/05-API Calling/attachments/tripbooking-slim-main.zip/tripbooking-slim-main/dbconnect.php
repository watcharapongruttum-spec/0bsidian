<?php
    $servername = 'localhost';
    $username = 'tripbooking';
    $password = 'tripbooking@csmsu';
    $dbname = 'tripbooking';

    $connect = new mysqli($servername, $username, $password, $dbname);
    $connect->set_charset("utf8");


