-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 06, 2023 at 06:50 AM
-- Server version: 8.0.20-0ubuntu0.19.10.1
-- PHP Version: 7.3.11-0ubuntu0.19.10.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tripbooking`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `idx` int NOT NULL,
  `customerid` int NOT NULL,
  `bookdatetime` datetime NOT NULL,
  `tripid` int NOT NULL,
  `meetingid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `idx` int NOT NULL,
  `fullname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `image` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`idx`, `fullname`, `phone`, `email`, `image`, `password`) VALUES
(1, 'ผู้ใช้ ทดสอบ', '0817399999', 'user1@gmail.com', 'http://202.28.34.197:8888/contents/4a00cead-afb3-45db-a37a-c8bebe08fe0d.png', '1111');

-- --------------------------------------------------------

--
-- Table structure for table `destination`
--

CREATE TABLE `destination` (
  `idx` int NOT NULL,
  `zone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `destination`
--

INSERT INTO `destination` (`idx`, `zone`) VALUES
(1, 'เอเชีย'),
(2, 'ยุโรป'),
(3, 'เอเชียตะวันออกเฉียงใต้'),
(9, 'ประเทศไทย');

-- --------------------------------------------------------

--
-- Table structure for table `meeting`
--

CREATE TABLE `meeting` (
  `idx` int NOT NULL,
  `detail` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `meetingdatetime` datetime NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `trip`
--

CREATE TABLE `trip` (
  `idx` int NOT NULL,
  `name` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `country` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `destinationid` int NOT NULL,
  `coverimage` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `detail` varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price` int NOT NULL,
  `duration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trip`
--

INSERT INTO `trip` (`idx`, `name`, `country`, `destinationid`, `coverimage`, `detail`, `price`, `duration`) VALUES
(1, 'อันซีนสวิตเซอร์แลนด์', 'สวิตเซอร์แลนด์', 2, 'https://themomentum.co/wp-content/uploads/2018/10/TheMo_Thumbnail-Switzerland.png', 'เที่ยวเต็มอิ่ม กับทัวร์สวิตเซอร์แลนด์ พร้อมเส้นทางฮิต นำท่านเยือนเมืองชาฟเฮาเซ่น ชมน้ำตกไรน์ ที่มีขนาดใหญ่ที่สุดในยุโรป เที่ยวกรุงเบิร์น ตามรอยเสด็จประพาส ณ เมืองโลซานน์ ชมปราสาทชิลยอง เที่ยวเมืองเซอร์แมท ชมยอดเขาแมททอร์ฮอร์น เที่ยวเมืองเวเว่ย์ ฉายา ไข่มุกแห่งริเวียร่าสวิส พิชิต 2 เขา ยอดเขาจุงเฟรา (Jungfrau) และ เขากลาเซียร์ 3000 (Glacier 3000 *ทานอาหารกลางวันบนเรือสำราญทะเลสาบเจนีวา *พร้อมอร่อยกับเมนูพิเศษ Swiss Fondue จองเลย', 119900, 10),
(2, 'สิงคโปร์ SENTOSA ยูนิเวอร์แซล', 'สิงคโปร์', 3, 'https://ik.imagekit.io/tvlk/image/imageResource/2019/05/29/1559127190516-bdfef6557456c167ac408415b15863f2.jpeg?tr=q-75', 'เที่ยวสวนสนุกระดับโลก Universal Studio จุดชมวิวแบบ 360 องศา แห่งใหม่ที่สูงที่สุดของสิงคโปร์ SkyHelix Sentosa (รวมค่าบัตร) ขอพรเทพเจ้าแห่งโชคลาภ ”ไฉ่ ซิ้ง เอี้ย” ที่ วัดซัมบาวัง (Sembawang God of Wealth Temple) นั่งเรือ Bumboat แบบคลาสสิคโบราณชมบรรยากาศริมน้ำ ไฮไลท์ของสิงคโปร์ (รวมค่าบัตร) ชมเมืองสิงคโปร์ และ ถ่ายรูปคู่เมอร์ไลอ้อน สัญลักษณ์ของประเทศ สัมผัส Fountain of wealth น้ำพุแห่งความมั่งคั่ง ช้อปปิ้งสินค้า BRAND NAME ที่มารีน่าเบย์แซนด์ และถนนออร์ชาด พร้อมเดินถ่ายรูปสบายๆ FORT CANNING PARK อุโมงค์ต้นไม้ในสวนสาธารณะโบราณ ยุคสงครามโลก ชม THE JEWEL CHANGI ที่สุดแห่งการผสมผสานระหว่างธรรมชาติและสถาปัตยกรรม เข้าชม GARDEN BY THE BAY สวนแห่งเทคโนโลยีที่ใหญ่ที่สุดบนเกาะสิงคโปร์ รวม น้ำดื่มบริการทุกวันวันละ 1 ขวด จองได้แล้ววันนี้ ', 22999, 4),
(3, 'ดานัง ฮอยอัน เว้ พักบนบานาฮิลล์', 'เวียดนาม', 3, 'https://khonkheetiew.com/wp-content/uploads/2021/04/DSCF3432-1024x683.jpg', 'นั่งกระเช้าขึ้นบาน่าฮิลล์ และ เล่นสวนสนุกบนบาน่าฮิลล์แบบไม่อั้น ชมวิวบนสะพานมือสีทอง(Golden Bridge) และชมโรงไวน์อายุกว่า 100ปี บนบาน่าฮิลล์ เที่ยวครบทุกไฮไลท์ ล่องเรือกระด้ง และ ช้อปปิ้ง 2 ตลาดดัง ดองบา ตลาดฮาน ตื่นตาไปกับมังกรพ่นไฟ และ ล่องเรือชมสองฝั่งแม่น้ำหอม นั่งรถซิโคล่ชมเมืองเว้ อิ่มอร่อยกับบุฟเฟ่ต์นานาชาติ บนบาน่าฮิลล์ และ เมนู SEAFOOD 2 มื้อ บริการห้องรับรองที่สนามบินสุวรรณภูมิ (บูทีคเลาจ์น) ฟรีหมวกเวียดนามท่านละ 1 ใบ และ Wi Fi on Bus พักโรงแรม 4 ดาว ทุกคืน บนบาน่าฮิลล์ 1 คืน 4 ดาว / เว้ 4 ดาว / ดานัง 4 ดาว จองได้แล้ววันนี้ ', 13899, 4),
(4, 'หลวงพระบาง', 'ลาว', 3, 'https://blog.bangkokair.com/wp-content/uploads/2017/11/shutterstock_289788734.jpg', 'ร่วมพิธีตักบาตรข้าวเหนียว ทุกเช้าชาวหลวงพระบางทุกบ้านจะพากันออกมานั่งรอตักบาตรพระสงฆ์ นมัสการพระบาง พระคู่บ้านคู่เมืองของชาวหลวงพระบาง วัดเชียงทอง วัดหลวงคู่บ้านคู่เมือง พระธาตุภูษี ชมความงดงามของ น้ำตกตาดกวางสี ที่ตกลดหลั่นเป็นชั้นๆ อย่างสวยงาม นั่งเรือล่องแม่น้ำโขงชม วิถีชีวิตของบ้านช่างไห่ และถ้ำติ่ง วัดวิชุนราช นมัสการพระธาตุหมากโม เที่ยวชมถนนข้าวเหนียว หรือตลาดมืด ให้ทุกท่านได้เลือกซื้อสิ้นค้าพื้นเมืองมากมาย จองได้แล้ววันนี้', 14999, 3),
(5, 'ไอซ์แลนด์ ตามล่าแสงเหนือ', 'ไอซ์แลนด์', 2, 'https://img.kapook.com/u/2021/sutasinee/02/i9.jpg', 'ทัวร์ยุโรป พาท่านตามล่าแสงเหนือ ดินแดนแห่งธรรมชาติ เที่ยวครบไอซ์แลนด์ใต้ - ตะวันออก โปรแกรมไม่เร่งรีบ ชม Plane Wrack ขับ Snow mobile บนกราเซีย แวะช็อปปิ้งเฮลซิงกิ พิเศษ!! ทานอาการโดมกระจก 360 องศา ที่ Perlan', 149999, 10),
(6, 'แกรนด์เยอรมันนีตอนใต้', 'เยอรมันนี', 2, 'https://happylongway.com/wp-content/uploads/2018/07/neuschwanstein-castle.jpg', 'นำท่านเดินทางถึงประเทศเยอรมันนี เดินทางสู่กรุงเบอร์ลิน นำท่านชมเมือง ถ่ายภาพคู่กับประตูชัยบราเดนเบิร์ก ชมเช็คพ้อยส์ ชาร์ลี ชมความสวยงามอันโดดเด่นของเดอะเซมเพอร์โอเปร่าเฮ้าท์ แวะถ่ายภาพด้านหน้าพระราชวังนิมเฟนบูร์ก นำท่านนั่งกระเช้าขึ้นชมยอดเขาซุกสปิตซ์ นำท่านเข้าชมภายในปราสาทนอยชวานชไตน์ ล่องเรือชมความสวยงามสองฝากฝั่งแม่น้ำไรน์ และเดินทางสู่เมืองแฟรงค์เฟิร์ต ชมจัตุรัสโรเมอร์ จองด่วนวันนี้!!!', 87900, 10),
(7, ' โตเกียว ฟูจิ', 'ญี่ปุ่น', 1, 'https://img.kapook.com/u/2020/juthamat/Jutha04/247025746.jpg', 'นำทุกท่านเดินทางถึงประเทศญี่ปุ่นอันแสนคิดถึง นำทุกท่านล่องเรือทะเลสาบอาชิอันสวยงาม นำทุกท่านชมยอดเขาโอวาคุดานิ นำทุกท่านเดินทางขึ้นสู่ยอดเขาฟูจิ เยี่ยมชมศูนย์จำลองแผ่นดินไหว ชมความสวยงามของสวนดอกไม้ฮานาโกะมิยากิ นำทุกท่านสักการะวัดอาซากุสะ เดินเล่นถนนนนากามิเสะ แวะถ่ายรูปกับโตเกียวสกายทรี ชมความสวยงามของพระราชวังอิมพีเรียล ช็อปปิ้งย่านชิจูกุ จองด่วนวันนี้ !', 30999, 5),
(8, 'คลับเมดฟิโนลูห์ วิลล่า มัลดีฟส์', 'มัลดีฟส์', 1, 'https://i.pinimg.com/originals/67/29/c9/6729c9b81367e36c9b505256f76e7c63.jpg', 'เที่ยวมัลดีฟส์ คลับเมด รีสอร์ทสุดหรู น่าจับตาแห่งใหม่ที่ มัลดีฟส์คลับเมดเปิด ฟิโนลูห์ วิลล่า รีสอร์ทเหนือระดับแห่งใหม่ ซึ่งจะพร้อมไปด้วยสิ่งอำนวยความสะดวกและการบริการอย่างเหนือระดับ ที่แขกทุกท่านสามารถเลือกที่จะเข้าพัก ในราคาพิเศษ พร้อมตั๋วเครื่องบินไปกลับ เลือกเดินทางได้เลยวันนี้', 41300, 3),
(9, 'มหัศจรรย์...อินเดีย', 'อินเดีย', 1, 'https://www.worldtourcenter.com/uploads/images/a1ddc4cc209f25defd7e090fdb7ba7de.jpg', 'นำท่านเดินทางสู่ประเทศอินเดีย ชมทัชมาฮาล 1 ใน 7 สิ่งมหัศจรรย์ของโลก เที่ยวชมเมืองชัยปุระ นครสีชมพู นั่งรถจีปขึ้นไปชมพระราชวัง AMBER FORT ชมพระราชวังหลวงถ่ายรูป ลานนกยูง จุดไฮไลท์ที่นักท่องเที่ยวนิยม ชมอัคราฟอร์ทป้อมปราการสำคัญ ชมแชนด์ เบารี โบราณสถานอันเก่าแก่ เป็นบ่อน้ำขั้นบันไดที่ลึกที่สุดในอินเดีย พิเศษ...สักการะวัดพระพิฆเนศ จองได้แล้ววันนี้!!', 23999, 4),
(10, 'มาเลเซีย เก็นติ้งสกายเวิล์ด', 'มาเลเซีย', 3, 'https://assets.nst.com.my/images/articles/hm3101gen_1644323834.jpg', 'นำท่านท่องเที่ยวประเทศมาเลเซีย พาเที่ยวสวนสนุกระดับโลก กลางสายหมอก GENTING SKY WORLD THEME PARK เที่ยวชมเมืองในสายหมอก GENTING HIGHLAND รวมนั่งกระเช้า CABLE CAR แล้ว เล่นคาสิโน เดินช้อปปิ้ง SKY AVENUE COMPLEX SKYTROPOLIS FUNLAND สักการะขอพรวัด CHINSWEE วัดถ้ำบาตู BATU CAVE ถ่ายรูปตึกแฝด PETRONAS TOWER ช้อปปิ้งห้างสุดหรู KLCC SURIA จองได้แล้ววันนี้!!', 7999, 3),
(11, 'เต็มอิ่มมหานครปารีส', 'ฝรั่งเศส ', 2, 'https://yourparishome.com/wp-content/uploads/2017/12/paris-yourhome.jpg', 'นำท่านเดินทางสู่ มหานครปารีส ชมมหาวิหารซาเคร เกอร์ ผ่านลานประวัติศาสตร์ จัตุรัสคองคอร์ด ถนนสายโรแมนติก ชองป์เอลิเซ่ ถ่ายรูปคู่กับประตูชัยนโปเลียน ล่องเรือบาโตมุช ช๊อปปิ้งที่ CHIC OUTLET LA VALLEE VILLAGE ชมความงดงามของ พระราชวังแวร์ซายส์ เข้าชมมหาวิหารมองซ์แซงต์มิเชล อิสระเที่ยวปารีสเต็มวัน จองได้แล้ววันนี้', 49999, 7),
(12, 'เกาหลี เล่นสกี เกาะนามิ', 'เกาหลี', 1, 'https://image.kkday.com/v2/image/get/w_960%2Cc_fit%2Cq_55%2Ct_webp/s1.kkday.com/product_19846/20180828014553_SgyVe/jpg', 'ทัวร์เกาหลี สัมผัสฤดูหนาวแรกและสุดมันส์ไปกับการเล่นหิมะเกาหลีที่ ลานสกี พร้อมพัก สกีรีสอร์ท 1 คืน ชม ช็อป ชิม ไปกับ ไร่สตรอเบอร์รี่ สดๆหวานฉ่ำจากไร่ ผลใหญ่ลูกมหึมา! ตามรอยซีรี่ย์เกาหลีที่ฮิตตลอดกาล พร้อมหิมะขาวโพลนที่แสนโรแมนติกกับ เกาะนามิ เช็คอินแลนด์มาร์คเกาหลี โซลทาวเวอร์ พร้อมคล้องกุญแจรักโรแมนติก ช้อปปิ้งจุใจไปกับ ตลาดเมียงดง และเต็มอิ่มให้พุงกางกับร้านอาหาร STREET FOOD จองได้แล้ววันนี้!!!', 30888, 5),
(13, 'เชียงใหม่ แม่ริม พักม่อนแจ่ม', 'ประเทศไทย', 9, 'https://roijang.com/wp-content/uploads/2022/08/asian-woman-posing-margaret-flower-field-1.jpg', 'นำท่านสู่ แม่กำปอง เป็นหมู่บ้านเล็กๆ ตั้งอยู่ท่ามกลางขุนเขา มีทรัพยากรธรรมชาติที่อุดมสมบูรณ์ เยี่ยมชมสักการะ วัดพระธาตุดอยสุเทพ เดินเล่นสุดฟิน ณ ฟาร์มทุ่งดอกไม้ แห่งอำเภอแม่ริม จังหวัดเชียงใหม่ ท่านจะได้พบกับความสวยงามของดอกไม้หลากหลายชนิด จากนั้นนำท่านเดินทางไปยัง “สวนส้มยอดดอย” บ้านแม่ขิ เชียงใหม่ สถานที่เที่ยวใหม่ ห่างจากม่อนแจ่มประมาณ 8 กิโลเมตร ท่านจะได้ฟินกับสวนส้มที่ละลานตาเต็มต้นจนอดใจจะถ่ายรูปด้วยไม่ได้เลยทีเดียว', 12999, 3),
(14, 'แอ่วเมืองน่าน', 'ประเทศไทย', 9, 'https://s.isanook.com/tr/0/ud/279/1395029/watphumin.jpg', 'เยือนเมืองน่าน เมืองแห่งความอุดมสมบูรณ์ป่าเขา และเข้มแข็งทางวัฒนธรรมกับประวัติศาสตร์อันยาวนานมากกว่า 700 ปี ไปสักการะ เสาพระหลักเมืองน่าน ณ วัดมิ่งเมือง เยี่ยมชม วัดภูมินทร์ ซึ่งมีภาพที่มีชื่อเสียงที่สุดคือภาพ \'ปู่ม่านย่าม่าน\' ต่อด้วยเข้าชมพิพิธภัณฑสถานแห่งชาติน่าน ที่มีไฮไลท์สำคัญคือ งาช้างดำและซุ้มลีลาวดี จากนั้นเที่ยวชมวัดพระธาตุช้างค้ำวรวิหาร, วัดพระธาตุแช่แห้ง ที่มีพระธาตุประจำปีเกิดของปีเถาะ, วัดพระธาตุเขาน้อย ตกเย็นเข้าสู่ตัวเมืองเดินเล่นที่ กาดข่วงเมืองน่าน จากนั้นเดินทางสู่ อ.บ่อเกลือ แวะถ่ายรูปที่ \"ถนนหมายเลข 3\" ที่นับว่าเป็น Unseen แห่งใหม่ของจังหวัดน่าน ชมบ่อเกลือสินเธาว์ มุ่งหน้าสู่หมู่บ้านสะปัน นั่งชิลที่ หยุดเวลาคาเฟ่ คาเฟ่มุมสวยที่สุดแห่งหมู่บ้านสะปัน แวะถ่ายรูปที่จุดชมวิว 1715 เดินทางขึ้นชมวิวรับอากาศหนาวดอยสกาด หมู่บ้านกลางสายหมอก เดินทางสู่วัดภูเก็ต ที่มีอุโบสถทรงล้านนาประยุกต์ ประดิษฐานหลวงพ่อแสนปัว หรือ หลวงพ่อพุทธเมตตา ปิดท้ายด้วย ร้านกาแฟไทลื้อ ร้านกาแฟที่ตั้งอยู่กลางทุ่งนาและขุนเขา', 9999, 3),
(15, 'หลีเป๊ะ อ่าวพันเตมะละกา', 'ประเทศไทย', 9, 'https://f.ptcdn.info/563/018/000/1399260850-lipe23-o.jpg', 'นำท่านเดินทางถึงสนามบินหาดใหญ่ สักการะศาลเจ้าพ่อตะรุเตา ชมอ่าวพันเตมะละกา เกาะตะรุเตา เดินทางสู่ เกาะไข่ ชมประติมากรรมทางธรรมชาติ นำท่านสู่เกาะหลีเป๊ะ อิสระกับการเล่นน้ำ นำท่านลงเรือหางยาวเพื่อออกดำน้ำจุดแรก ณ อ่าวแม่หม้าย เดินทางไปยัง เกาะกระ ชมความสวยงามของหาดทรายขาวสะอาดและน้ำทะเลใส ดำน้ำเกาะตาลัง และช้อปปิ้งสินค้าราคาถูกมากมายบริเวณ ตลาดกิมหยง', 9999, 3),
(16, 'เพชรบูรณ์ ภูทับเบิก', 'ประเทศไทย', 9, 'http://travel.mthai.com/app/uploads/2014/10/1411544180-011-o.jpg', 'เที่ยวเมืองในหมอกสุดฟิน เสพย์บรรยากาศเมืองโบราณ ร่วมสักการะเจดีย์ \"พระธาตุผาซ่อนแก้ว\" และชมวิวทะเลหมอกช่วงหน้าฝน และทุ่งดอกกระหล่ำที่เขียวขจีนับร้อยๆต้น ถือว่าเป็น 1 ใน UNSEEN NATURES AND WONDERS ในจังหวัดเพชรบูรณ์ ฟินกับการถ่ายรูปกับทุ่งดอกมากาเร็ตสีม่วงนับพันๆต้น ทิ้งท้ายด้วยการเช็คอิน จุดแลนด์มาร์ก แทนรัก ทะเลหมอก หรือชื่อเป็นที่รู้จักกัน คือ บ้านสีส้ม ซึ่งเป็นจุดชมวิวที่สวยแห่งหนึ่งของเขาค้อ', 4999, 3),
(17, 'สกลนคร นครพนม บึงกาฬ ถ้ำนาคา', 'ประเทศไทย', 9, 'https://tidroam.com/wp-content/uploads/2021/09/Whales-Rock.jpg', 'มหัศจรรย์สองดินแดน ถิ่นนาคา ถ้ำนาคี เที่ยวชมถ้ำนาคี ของดีคู่ ถ้ำนาคา ชมพระอาทิตย์ตก ณ หินสามวาฬ เดินทางสู่ถ้ำนาคาหรือถ้ำพญานาค ที่ตั้งอยู่ในอุทยานแห่งชาติภูลังกา จากนั้นไปที่บึงโขงหลง แวะไหว้ขอพรศาลปู่อือลือนาคราช ตกเย็น เดินเที่ยวที่ถนนคนเดินนครพนม พร้อมสักการะพญาศรีสัตตนานาคราช เที่ยวชมพระธาตุพนม พระธาตุประจำวันอาทิตย์ และพระธาตุน้อยศรีบุญเรือง', 7999, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`idx`),
  ADD KEY `tripid` (`tripid`),
  ADD KEY `meetingid` (`meetingid`),
  ADD KEY `customerid` (`customerid`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`idx`);

--
-- Indexes for table `destination`
--
ALTER TABLE `destination`
  ADD PRIMARY KEY (`idx`);

--
-- Indexes for table `meeting`
--
ALTER TABLE `meeting`
  ADD PRIMARY KEY (`idx`);

--
-- Indexes for table `trip`
--
ALTER TABLE `trip`
  ADD PRIMARY KEY (`idx`),
  ADD KEY `destinationid` (`destinationid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `idx` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `idx` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `destination`
--
ALTER TABLE `destination`
  MODIFY `idx` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `meeting`
--
ALTER TABLE `meeting`
  MODIFY `idx` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trip`
--
ALTER TABLE `trip`
  MODIFY `idx` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`tripid`) REFERENCES `trip` (`idx`) ON UPDATE CASCADE,
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`meetingid`) REFERENCES `meeting` (`idx`) ON UPDATE CASCADE,
  ADD CONSTRAINT `booking_ibfk_3` FOREIGN KEY (`customerid`) REFERENCES `customer` (`idx`) ON UPDATE CASCADE;

--
-- Constraints for table `trip`
--
ALTER TABLE `trip`
  ADD CONSTRAINT `trip_ibfk_1` FOREIGN KEY (`destinationid`) REFERENCES `destination` (`idx`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
