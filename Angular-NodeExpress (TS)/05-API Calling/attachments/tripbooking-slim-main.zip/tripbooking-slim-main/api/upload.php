<?php
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\UploadedFileInterface;


function moveUploadedFile(string $directory, UploadedFileInterface $uploadedFile)
{
    $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
    // see http://php.net/manual/en/function.random-bytes.php
    $basename = bin2hex(random_bytes(8));
    $filename = sprintf('%s.%0.8s', $basename, $extension);
    $uploadedFile->moveTo($directory . DIRECTORY_SEPARATOR . $filename);
    return $filename;
}


$app->post('/upload', function (ServerRequestInterface $request, ResponseInterface $response) {
    $directory = $this->get('upload_directory');
    $uploadedFiles = $request->getUploadedFiles();

    $uploadedFile = $uploadedFiles['file'];
    if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
        $filename = moveUploadedFile($directory, $uploadedFile);
    }

    // // handle multiple inputs with the same key
    // foreach ($uploadedFiles['example2'] as $uploadedFile) {
    //     if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
    //         $filename = moveUploadedFile($directory, $uploadedFile);
    //         $response->getBody()->write('Uploaded: ' . $filename . '<br/>');
    //     }
    // }

    // // handle single input with multiple file uploads
    // foreach ($uploadedFiles['example3'] as $uploadedFile) {
    //     if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
    //         $filename = moveUploadedFile($directory, $uploadedFile);
    //         $response->getBody()->write('Uploaded: ' . $filename . '<br/>');
    //     }
    // }

    $server = $_SERVER['SERVER_ADDR'];
    $port = $_SERVER['SERVER_PORT'];
    if($port == 80){
        $port = '';
    }else{
        $port = ':' . $port ;
    }
    $data = ['filename' => '/tripbooking/uploads/'.$filename];
    $response->getBody()->write(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_NUMERIC_CHECK));
    return $response
        ->withHeader('Content-Type', 'application/json; charset=utf-8')
        ->withStatus(200);
});
