<?php

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

$app->get('/trip', function (Request $request, Response $response) {
    $conn = $GLOBALS['connect'];

    $queryParams = $request->getQueryParams();
    $sql = 'select * from trip';
    $stmt = $conn->prepare($sql);
    if (isset($queryParams['name'])) {
        $sql = 'select * from trip where name like ?';
        $stmt = $conn->prepare($sql);
        $name = '%' . $queryParams['name'] . '%';
        $stmt->bind_param('s', $name);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $data = array();
    foreach ($result as $row) {
        array_push($data, $row);
    }

    $response->getBody()->write(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_NUMERIC_CHECK));
    return $response
        ->withHeader('Content-Type', 'application/json; charset=utf-8')
        ->withStatus(200);
});

$app->get('/trip/{id}', function (Request $request, Response $response, $args) {
    $conn = $GLOBALS['connect'];
    $sql = 'select * from trip where idx = ?';
    $stmt = $conn->prepare($sql);

    $stmt->bind_param('s', $args['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = array();
    foreach ($result as $row) {
        array_push($data, $row);
    }

    $response->getBody()->write(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_NUMERIC_CHECK));
    return $response
        ->withHeader('Content-Type', 'application/json; charset=utf-8')
        ->withStatus(200);
});

$app->post('/trip', function (Request $request, Response $response, $args) {
    $json = $request->getBody();
    $jsonData = json_decode($json, true);

    $conn = $GLOBALS['connect'];
    $sql = 'INSERT INTO `trip`(`name`, `country`, `destinationid`, `coverimage`, `detail`, `price`, `duration`) VALUES (?,?,?,?,?,?,?)';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssissii', $jsonData['name'], $jsonData['country'], $jsonData['destinationid'], $jsonData['coverimage'], $jsonData['detail'], $jsonData['price'], $jsonData['duration']);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    if ($affected > 0) {
        $data = ["affected_rows" => $affected, "last_idx" => $conn->insert_id];
        $response->getBody()->write(json_encode($data));
        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }else {
        $data = ["affected_rows" => $affected];
        $response->getBody()->write(json_encode($data));
        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }
});

$app->put('/trip/{id}', function (Request $request, Response $response, $args) {
    $json = $request->getBody();
    $jsonData = json_decode($json, true);
    $idx = $args['id'];

    $conn = $GLOBALS['connect'];
    $sql = 'UPDATE `trip` SET `name`=?,`country`=?,`destinationid`=?,`coverimage`=?,`detail`=?,`price`=?,`duration`=? WHERE `idx`=?';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssissiii', $jsonData['name'], $jsonData['country'], $jsonData['destinationid'], $jsonData['coverimage'], $jsonData['detail'], $jsonData['price'], $jsonData['duration'], $idx);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $data = ["affected_rows" => $affected];
    $response->getBody()->write(json_encode($data));
    return $response
        ->withHeader('Content-Type', 'application/json')
        ->withStatus(200);
});

$app->delete('/trip/{id}', function (Request $request, Response $response, $args) {
    $id = $args['id'];
    $conn = $GLOBALS['connect'];
    $sql = 'delete from trip where idx = ?';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $data = ["affected_rows" => $affected];
    $response->getBody()->write(json_encode($data));
    return $response
        ->withHeader('Content-Type', 'application/json')
        ->withStatus(200);
});
